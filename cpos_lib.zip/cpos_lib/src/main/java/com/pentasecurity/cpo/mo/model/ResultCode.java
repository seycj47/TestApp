package com.pentasecurity.cpo.mo.model;

public enum ResultCode {
    SUCCESS, FAIL;
}
