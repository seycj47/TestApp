package com.pentasecurity.cpo.mo.model;

public class SignedData {
	
	private String base64EncodedSignedData;
	
	public SignedData() {
		
	}
	
	public SignedData(String base64EncodedSignedData) {
		this.base64EncodedSignedData = base64EncodedSignedData;
	}

}
